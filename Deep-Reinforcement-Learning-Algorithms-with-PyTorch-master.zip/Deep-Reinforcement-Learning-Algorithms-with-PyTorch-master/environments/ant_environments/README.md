NOTE that all code in this folder came directly from the github repo https://github.com/tensorflow/models/tree/master/research/efficient-hrl/environments 
and is not my code. 